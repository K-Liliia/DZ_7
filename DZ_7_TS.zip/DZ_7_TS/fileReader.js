const fs = require('fs');

// Read the JSON file
fs.readFile('spaces.json', 'utf8', (err, data) => {
    if (err) {
        console.error('Error reading file:', err);
        return;
    }
    
    try {
        // Parse the JSON data
        var jsonData = JSON.parse(data);
        console.log('Task 1');
        // Extract list IDs
        const listIds = jsonData.folders.flatMap(folder => 
            folder.lists.map(list => list.id)
        );
        console.log('List IDs:', listIds);
        console.log('-------------------------------');
        console.log('Task 2');

        const spaces = jsonData.folders.flatMap(folder => 
            folder.lists
                .filter(list => {
                    return list.name.startsWith('test');
                })
                .map(list => ({
                    id: list.space.id,
                    name: list.space.name
                }))
        );

        console.log('Spaces starting with "test":', spaces);

    } catch (parseError) {
        console.error('Error parsing JSON:', parseError);
    }
});
