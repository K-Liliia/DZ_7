import json

# Read the JSON file
with open('spaces.json', 'r') as file:
    data = json.load(file)

# Extract all list IDs
list_ids = [
    list_item['id']
    for folder in data['folders']
    for list_item in folder['lists']
]

# Print the results
print('List IDs:', list_ids)

# Extract space names and ids from lists where the space name starts with "test"
spaces = [
    {
        "id": list_item['space']['id'],
        "name": list_item['space']['name']
    }
    for folder in data['folders']
    for list_item in folder['lists']
    if list_item['name'].startswith('test')  # Check if space name starts with "test"
]

# Print the results
print('Spaces starting with "test":', spaces)
