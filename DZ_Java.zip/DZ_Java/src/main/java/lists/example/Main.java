package lists.example;

// Press ⇧ twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        List<String> lines = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("/Users/liliiakozachuk/IdeaProjects/DZ_7_Java/src/spaces.json"))) {
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Now you can use the lines as a List
        for (String line : lines) {
            System.out.println(line);
        }

        String jsonString = lines;
        // Parse JSON
        JSONObject jsonObject = new JSONObject(jsonString);
        JSONArray folders = jsonObject.getJSONArray("folders");
        System.out.println("Task 1");

        // Iterate through folders and extract list IDs
        for (int i = 0; i < folders.length(); i++) {
            JSONObject folder = folders.getJSONObject(i);
            JSONArray lists = folder.getJSONArray("lists");

            for (int j = 0; j < lists.length(); j++) {
                JSONObject list = lists.getJSONObject(j);
                String listId = list.getString("id");
                System.out.println("List ID: " + listId);
            }
        }
        System.out.println("------------------------------");
        System.out.println("Task 2");

        // Iterate through folders and lists to check space names
        for (int i = 0; i < folders.length(); i++) {
            JSONObject folder = folders.getJSONObject(i);
            JSONArray lists = folder.getJSONArray("lists");

            for (int j = 0; j < lists.length(); j++) {
                JSONObject list = lists.getJSONObject(j);
                JSONObject space = list.getJSONObject("space");
                String spaceName = space.getString("name");
                String spaceId = space.getString("id");

                // Check if the space name starts with "test"
                if (spaceName.startsWith("test")) {
                    System.out.println("Space Name: " + spaceName);
                    System.out.println("Space Name: " + spaceId);
                }
            }
        }
    }
}